# Open Source Showcase UI

The handwritten notebook frontend for `opensource-showcase`.

Developer GitHub details appear in a left column, with merged open source contributions in the main column. Cream and Classic themes share the same ruled paper, margins, handwriting, and ink colors. Profiles stack above contributions on smaller screens.

## Development

```sh
npm ci
npm run dev
```

Open `/notebook.html`. Preview data lives in `public/contributions.json`.

## Package

```sh
npm run build
npm pack
```

The build emits `dist/showcase-ui.js`. The bundle contains its CSS and Patrick Hand font so generated GitHub Pages sites need no separate font setup. The font license is included at `dist/fonts/OFL.txt`.

The host page supplies a `root` element and either `window.__SHOWCASE_DATA__` or a sibling `contributions.json` file.

## Release order

Publish `opensource-showcase-ui@1.1.0` first, then `opensource-showcase@0.1.19`. The CLI generates pages referencing the exact UI version on jsDelivr.
